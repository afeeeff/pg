import React from 'react';
import PGAutomation from './PGAutomation';

function App() {
  return (
    <div className="App">
      <PGAutomation />
    </div>
  );
}

export default App;
